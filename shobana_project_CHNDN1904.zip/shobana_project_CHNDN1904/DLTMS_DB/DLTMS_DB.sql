create database DLTMS_DB
create table User_Details
(
First_Name varchar(50) Not null,
Last_Name varchar(50) Not null,
Date_of_Birth datetime Not null,
Age int Not null,
Gender char(6) Not null,
Contact_no varchar(11),
UserId char(15) primary key not null,
UserPassword varchar(15) not null,
Email varchar(50) not null,
UserType char(1),
)

select * from user_Details
Alter procedure validateUserLogin @UserId char(10),@UserPassword varchar(15),@utype char(1),
@status varchar(10) out
as
Begin
	Declare @uid char(10)
	set @uid=''
	Select @uid=UserId from User_Details where UserId=@UserId and UserPassword=@UserPassword and UserType=@utype
	if @uid=''
		Set @status='Invalid'
	else
		Set @status='valid'
End

Begin
Declare @status varchar(10)
Exec validateUserLogin '1','2', @status out
select @status
End

create procedure Insert_User_Details @First_Name varchar(50),
@Last_Name varchar(50),
@Date_of_Birth datetime,
@Age int,
@Gender char(6),
@Contact_no varchar(11),
@UserId char(15),
@UserPassword varchar(15),
@Email varchar(50),
@UserType char(1)
as
Begin
Insert into User_Details values(@First_Name,
@Last_Name,
@Date_of_Birth,
@Age,
@Gender,
@Contact_no,
@UserId,
@UserPassword,
@Email,
@UserType)
End

sp_help User_Details

create procedure View_CourseDetails @Course_code varchar(10)
as
Begin
	Select * from Course_Details where Course_code=@Course_code 
End


create procedure View_QuestionDetails @Course_code varchar(10),@CourseQuestionNo int
as
Begin
	Select * from CourseWiseQuestion where Course_code=@Course_code and CourseQuestionNo=@CourseQuestionNo
End
------------------------------------------------------------------------------------------------------------------------------------
create table Course_Details
(
Course_code varchar(10) primary key not null,
Course_Description varchar(100) not null,
Skill_Set varchar(50) not null,
Couse_Date datetime Not null,
Course_Time varchar(10) Not null,
Other_reference varbinary(max) not null,
)

sp_help Course_Details
create table CourseWiseQuestion
(
Course_code varchar(10),
CourseQuestionNo int,
QuestionText varchar(100),
AnswerOption1 varchar(50), 
AnswerOption2 varchar(50),
CorrectAnswer varchar(50) 
)

select * from CourseWiseQuestion

create procedure InsertCourseWiseQuestion @Course_code varchar(10),@CourseQuestionNo int,@QuestionText varchar(100),@AnswerOption1 varchar(50), 
@AnswerOption2 varchar(50),@CorrectAnswer varchar(50) 
As
Begin
	Insert into CourseWiseQuestion values(@Course_code,@CourseQuestionNo,@QuestionText,@AnswerOption1,@AnswerOption2,@CorrectAnswer)
End

Alter procedure Search_CourseWiseQuestion @Course_code varchar(10),@CourseQuestionNo int
as
Begin
	Select * from CourseWiseQuestion where Course_code=@Course_code and CourseQuestionNo=@CourseQuestionNo
End

Create procedure Remove_CourseWiseQuestion @Course_code varchar(10),@CourseQuestionNo int
As
Begin
		Delete from CourseWiseQuestion where Course_code=@Course_code and CourseQuestionNo=@CourseQuestionNo
End

Delete from CourseWiseQuestion where Course_code='CRS0.28240' and CourseQuestionNo=5

Select * from CourseWiseQuestion 

Select * from Course_Details

delete from Course_Details

Alter table Course_Details
Add Other_reference varbinary(max)

Alter procedure Insert_Course_Details @Course_code varchar(10),
@Course_Description varchar(100),
@Skill_Set varchar(50),
@Couse_Date datetime,
@Course_Time varchar(10) ,
@Other_reference varbinary(max) 
as
Begin
Insert into Course_Details values(@Course_code,
@Course_Description,
@Skill_Set,
@Couse_Date,
@Course_Time ,
@Other_reference )
End

-------------------------------------------------------------------------------------------------------------------------
create table CourseCompletion_Details
(
UserID char(15) not null,
Course_code varchar(10) not null,
Completion_Date varchar(100) not null,
Score char(10) not null,
constraint fk_userid foreign key(UserId) references User_Details(UserId),
constraint fk_coursecode foreign key(Course_code) references Course_Details(Course_code)
)

select * from CourseCompletion_Details

create procedure Insert_CourseCompletion_Details @UserID char(15),
@Course_code varchar(10),
@Completion_Date varchar(100),
@Score char(10)
as
Begin
Insert into CourseCompletion_Details values(@UserID,
@Course_code,
@Completion_Date,
@Score )
End
--------------------------------------------------------------------------------------------------------------------------------
								/* USER DETAILS*/

create function SearchUser(@UserId char(15))
Returns Table
as
Return(select * from User_Details where UserId=@UserId)

create procedure Search_User_Details  
@UserId char(15)
As
Begin
select * from dbo.SearchUser(@UserId)
End

create procedure Remove_User @UserId char(15)
As
Begin
	Declare @recstatus int
	Set @recstatus=0

	if exists(Select *  from User_Details where UserId=@UserId)
	Begin
		Delete from User_Details where UserId=@UserId
		Set @recstatus =1
	End
	Else
		Set @recstatus=0 
Select @recstatus	
End

create procedure Edit_User_Details @First_Name varchar(50),
@Last_Name varchar(50),
@Date_of_Birth datetime,
@Age int,
@Gender char(6),
@Contact_no varchar(11),
@UserId char(15),
@Email varchar(50)
as
Begin
Update User_Details
Set First_Name=@First_Name,
Last_Name=@Last_Name,
Date_of_Birth=@Date_of_Birth,
Age=@Age,
Gender=@Gender,
Contact_no=@Contact_no,
Email=@Email where UserId=@UserId
End

--------------------------------------------------------------------------------------------------------------------------------
						/*   COURSE DETAILS*/

create function SearchCourse(@Course_code varchar(10))
Returns table
as
Return(select * from Course_Details where Course_code=@Course_code)

create procedure Search_Course_Details
@Course_code varchar(10)
as
Begin
Select * from dbo.SearchCourse(@Course_code)
End



Alter procedure Remove_Course @Course_code varchar(10)
As
Begin
	
		Delete from Course_Details where Course_code=@Course_code
		
End



Alter procedure Edit_Course @Course_code varchar(10),
@Course_Description varchar(100),
@Skill_Set varchar(50),
@Course_Date datetime,
@Course_Time varchar(10)
as
Begin
Update Course_Details
Set Course_code=@Course_code,Course_Description=@Course_Description,Skill_Set=@Skill_Set,Couse_Date=@Course_Date,
Course_Time=@Course_Time where Course_code=@Course_code
End
	
----------------------------------------------------------------------------------------------------------------------------
				/*    COURSE COMPLETION DETAILS*/




