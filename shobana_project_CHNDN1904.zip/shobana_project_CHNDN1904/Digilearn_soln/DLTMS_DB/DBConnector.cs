﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DLTMS_DB
{
    public class DBConnector
    {
        public static SqlConnection GetDBConnection()
        {
            SqlConnection con = new SqlConnection("Data Source=PC440984;Initial Catalog=DLTMS_DB;User ID=sa;Password=password-1");
            con.Open();
            return con;
        }

        public static string validateUserLogin(SqlConnection con, string uid, string psw, string utype)
        {
            string status = "";
            SqlCommand cmd = new SqlCommand("validateUserLogin", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@UserPassword", psw);
            cmd.Parameters.AddWithValue("@utype", utype);

            SqlParameter sp1 = new SqlParameter();
            sp1.ParameterName = "@status";
            sp1.SqlDbType = SqlDbType.VarChar;
            sp1.Size = 10;
            sp1.Direction = ParameterDirection.Output;  // direction is output;
            cmd.Parameters.Add(sp1);

            cmd.ExecuteReader();
            status=(string)sp1.Value;
            return status;
        }  
    }
}
