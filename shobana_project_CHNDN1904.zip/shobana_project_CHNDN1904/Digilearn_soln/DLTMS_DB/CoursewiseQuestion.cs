﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DLTMS_DB
{
    public class CoursewiseQuestion
    {
        public static int InsertQuestion(SqlConnection con, string CCode, int CQNo, string QText, string Ans1, string Ans2, string CorrectAnswer)
        {
            SqlCommand cmd = new SqlCommand("InsertCourseWiseQuestion", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Course_code", CCode);
            cmd.Parameters.AddWithValue("@CourseQuestionNo", CQNo);
            cmd.Parameters.AddWithValue("@QuestionText", QText);
            cmd.Parameters.AddWithValue("@AnswerOption1", Ans1);
            cmd.Parameters.AddWithValue("@AnswerOption2", Ans2);
            cmd.Parameters.AddWithValue("@CorrectAnswer", CorrectAnswer);
            return cmd.ExecuteNonQuery();

        }

        public static int GetQuestionsCount(SqlConnection con, string ccode)
        {
            SqlCommand cmd = new SqlCommand("Select count(*) from CourseWiseQuestion where Course_code='"+ccode+"'", con);
            cmd.CommandType = CommandType.Text;
            return (int)cmd.ExecuteScalar();
        }

        public static SqlDataReader GetQuestionDetails(SqlConnection con, string ccode, int CQNo)
        {
            SqlCommand cmd = new SqlCommand("Search_CourseWiseQuestion", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Course_code", ccode);
            cmd.Parameters.AddWithValue("@CourseQuestionNo", CQNo);
            SqlDataReader sdr = cmd.ExecuteReader();
            return sdr;
        }

        public static SqlDataReader GetQuestionDetails(SqlConnection con, string ccode)
        {
            SqlCommand cmd = new SqlCommand("Select * from CourseWiseQuestion where Course_code='"+ccode+"'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            return sdr;
        }

        
        public static int RemoveQuestionDetails(SqlConnection con, string ccode, int CQNo)
        {
            SqlCommand cmd = new SqlCommand("Remove_CourseWiseQuestion", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Course_code", ccode);
            cmd.Parameters.AddWithValue("@CourseQuestionNo", CQNo);
            return cmd.ExecuteNonQuery();
        }

    }
}
