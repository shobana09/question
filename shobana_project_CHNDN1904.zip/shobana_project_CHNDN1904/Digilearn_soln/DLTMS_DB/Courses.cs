﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DLTMS_DB
{
    /*
     create procedure Insert_Course_Details @Course_code varchar(10), @Course_Description varchar(100), @Skill_Set varchar(50), @Couse_Date datetime, @Course_Time varchar(10) ,
@Other_reference varchar(100) */
   
    public class Courses
    {
        public static int InsertCourseDetails(SqlConnection con, string ccode, string cdesc, string skill_set, DateTime CDate, string CTime, byte[] other)
        {
            SqlCommand cmd = new SqlCommand("Insert_Course_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Course_code", ccode);
            cmd.Parameters.AddWithValue("@Course_Description", cdesc);
            cmd.Parameters.AddWithValue("@Skill_Set", skill_set);
            cmd.Parameters.AddWithValue("@Couse_Date", CDate);
            cmd.Parameters.AddWithValue("@Course_Time", CTime);
            cmd.Parameters.AddWithValue("@Other_reference", other);
            return cmd.ExecuteNonQuery();

        }
        /*
         Alter procedure Edit_Course @Course_code varchar(10),@Course_Description varchar(100),
        @Skill_Set varchar(50),@Course_Date datetime,@Course_Time varchar(10),@Other_reference varbinary(max)
         */
        public static int EditCourseDetails(SqlConnection con, string ccode, string cdesc, string skill_set, DateTime CDate, string CTime)
        {
            SqlCommand cmd = new SqlCommand("Edit_Course", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Course_code", ccode);
            cmd.Parameters.AddWithValue("@Course_Description", cdesc);
            cmd.Parameters.AddWithValue("@Skill_Set", skill_set);
            cmd.Parameters.AddWithValue("@Course_Date", CDate);
            cmd.Parameters.AddWithValue("@Course_Time", CTime);
            return cmd.ExecuteNonQuery();

        }
        public static DataSet GetAllCoursesDetails(SqlConnection con)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Course_Details", con);
            sda.Fill(ds, "Course_Details");
            return ds;
        }

        public static SqlDataReader GetAllCoursesDetails(SqlConnection con, string ccode)
        {
            SqlCommand cmd = new SqlCommand("Select * from Course_Details where Course_code='"+ccode+"'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr=cmd.ExecuteReader();
            return sdr;
        }

        public static SqlDataReader GetAllCoursesDetails(SqlConnection con, string ccode, string skill)
        {
            SqlCommand cmd = new SqlCommand("Select * from Course_Details where Course_code='" + ccode + "' and Skill_Set='"+skill+"'", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            return sdr;
        }

        public static int RemoveCourse(SqlConnection con, string ccode)
        {
            //Remove_Course @Course_code varchar(10)
            SqlCommand cmd = new SqlCommand("Remove_Course", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Course_code", ccode);
            return cmd.ExecuteNonQuery();
        }

        public static DataSet ViewCourseDetails(SqlConnection con)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Course_Details", con);
            sda.Fill(ds, "Course_Details");
            return ds;
        }

        public static SqlDataReader GetAllCoursesSkills(SqlConnection con)
        {
            SqlCommand cmd = new SqlCommand("Select Course_code, Skill_Set from Course_Details", con);
            cmd.CommandType = CommandType.Text;
            SqlDataReader sdr = cmd.ExecuteReader();
            return sdr;
        }
         /*
         Insert_CourseCompletion_Details @UserID char(15),@Course_code varchar(10),@Completion_Date varchar(100),@Score char(10)*/
        public static int InsertCourseCompletionDetails(SqlConnection con, string userId, string ccode, DateTime completedate, int score)
        {
            SqlCommand cmd = new SqlCommand("Insert_CourseCompletion_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", userId);
            cmd.Parameters.AddWithValue("@Course_code", ccode);
            cmd.Parameters.AddWithValue("@Completion_Date", completedate.ToShortDateString());
            cmd.Parameters.AddWithValue("@Score", score.ToString());
            return cmd.ExecuteNonQuery();
           
        }

        public static string GetCourseCompleteStatus(SqlConnection con, string userId, string ccode)
        {
            SqlCommand cmd = new SqlCommand("Select Completion_Date from CourseCompletion_Details where Course_code='"+ccode+"' and UserID='"+userId+"'", con);
            cmd.CommandType = CommandType.Text;
            return (string)cmd.ExecuteScalar();
        }

        public static DataSet ViewCourseCompletionDetails(SqlConnection con)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from CourseCompletion_Details", con);
            sda.Fill(ds, "CourseCompletion_Details");
            return ds;
        }

        public static DataSet ViewCourseCompletionDetails(SqlConnection con,string ccode)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from CourseCompletion_Details where Course_code='"+ccode+"'", con);
            sda.Fill(ds, "CourseCompletion_Details");
            return ds;
        }
    }
}
