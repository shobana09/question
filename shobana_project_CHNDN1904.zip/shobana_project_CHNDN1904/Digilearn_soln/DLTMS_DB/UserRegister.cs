﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DLTMS_DB
{
   
    public class UserRegister
    {
        public static int RegisterUserDetails(SqlConnection con, string FN, string LN, DateTime DOB, int age, string G, string contact, string uid, string psw, string email, string utype)
        {
            SqlCommand cmd = new SqlCommand("Insert_User_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@First_Name", FN);
            cmd.Parameters.AddWithValue("@Last_Name", LN);
            cmd.Parameters.AddWithValue("@Date_of_Birth", DOB);
            cmd.Parameters.AddWithValue("@Age", age);
            cmd.Parameters.AddWithValue("@Gender", G);
            cmd.Parameters.AddWithValue("@Contact_no", contact);
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@UserPassword", psw);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@UserType", utype);
            return cmd.ExecuteNonQuery();



        }
    }
}
