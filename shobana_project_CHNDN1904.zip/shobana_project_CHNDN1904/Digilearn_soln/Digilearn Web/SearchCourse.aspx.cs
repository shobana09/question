﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace Digilearn_Web
{
    public partial class SearchCourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string uid = (string)Session["USERID"];
            lbUserId.Text = "Welcome " + uid + ", Page Access Time : " + DateTime.Now;

            if (!Page.IsPostBack)
            {
                GV1.Visible = false;
                pn1.Visible = false;
                pn2.Visible = false;
            }
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Digilearn_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            string ccode = txCourseID.Text;
            if (ccode.Equals("*"))
            {
                DataSet ds=CourseManagement.GetCoursesDetails();
                GV1.DataSource = ds;
                GV1.DataMember = ds.Tables[0].TableName;
                GV1.DataBind();
                pn1.Visible = true;
                GV1.Visible = true;
                pn2.Visible = false;
            }
            else
            {
                SqlDataReader sdr = CourseManagement.GetCoursesDetailsByCourseCode(ccode);
                if (sdr.Read())
                {
                    txCCode.Text = sdr[0].ToString();
                    txCDesc.Text = sdr[1].ToString();
                    txSkill.Text = sdr[2].ToString();
                    txCDate.Text = sdr[3].ToString();
                    txCTime.Text = sdr[4].ToString();
                }
                sdr.Close();
                pn2.Visible = true;
                pn1.Visible = false;
            }
        }

        protected void btnHide_Click(object sender, EventArgs e)
        {
            pn1.Visible = false;
        }
    }
}