﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Digilearn_Web
{
    public partial class UserHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string utype = (string)Session["USERID"];
            lbUserId.Text = "Welcome " +utype + ", Page Access Time : " + DateTime.Now;
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Digilearn_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void linkSearchCourse_Click(object sender, EventArgs e)
        {
            Response.Redirect("SearchCourse.aspx");

        }

       

        

       
 

        

        

    }
}