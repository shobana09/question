﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;

namespace Digilearn_Web
{
    public partial class Digilearn_Home1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void linkRegister_Click(object sender, EventArgs e)
        {
            if (ddlUtype.SelectedValue.Equals("None"))
            {
                Response.Redirect("UserRegister.aspx");
            }
            else  if(ddlUtype.SelectedValue.Equals("Admin"))
            {
                Response.Redirect("UserRegister.aspx?utype=Admin");
            }
            else if (ddlUtype.SelectedValue.Equals("User"))
            {
                Response.Redirect("UserRegister.aspx?utype=User");
            }
        }

        protected void ddlUtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlUtype.SelectedIndex == 0)
            {
                lbStatus.Text = "You must Select User Type";
                
            }
            else
            {
                lbStatus.Text = "";
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lbError.Text = "";
            lbStatus.Text = "";
            txPsw.Text = "";

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                String status = "";
                String uid = txUserId.Text;
                String psw = txPsw.Text;
                string utype = ddlUtype.SelectedValue;
                status=lbStatus.Text = UserTask.VerifyUserLoginStatus(uid,psw,utype);
                
                if (status.Equals("valid") && utype.Equals("Admin"))
                {
                    Session.Add("USERID", uid);
                    Response.Redirect("AdminHome.aspx");
                }
                if (status.Equals("valid") && utype.Equals("User"))
                {
                    Session.Add("USERID", uid);
                    Response.Redirect("UserHome.aspx");
                }
                else
                {
                    lbStatus.Text = status;
                }
            }
                
            catch(Exception ex)
            {
                lbStatus.Text = ex.Message;
            }
             

        }

        protected void txPsw_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}


