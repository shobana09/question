﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace Digilearn_Web
{
    public partial class StarLearn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                SqlDataReader sdr = CourseManagement.GetAllCoursesSkills();
                while (sdr.Read())
                {
                    string id_skill = sdr[0].ToString() + "-" + sdr[1].ToString();
                    ddlCourse.Items.Add(id_skill);
                    ddlCourse.SelectedIndex = 0;
                    pn1.Visible = false;
                }
                sdr.Close();
            }
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Digilearn_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void ddlCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlCourse.SelectedIndex == 0)
            {
                pn1.Visible = false;
            }
            else
            {
                pn1.Visible = true;
                string idskill = ddlCourse.SelectedValue;
                string courseid = idskill.Substring(0, idskill.IndexOf("-"));
                string skill = idskill.Substring(idskill.IndexOf("-")+1);
                SqlDataReader sdr=CourseManagement.GetAllCoursesDetails(courseid, skill);
                if (sdr.Read())
                {
                    txCCode.Text = sdr[0].ToString();
                    txSkill.Text = sdr[2].ToString();
                    txDesc.Text = sdr[1].ToString();
                    txCDate.Text = sdr[3].ToString();
                    txTime.Text = sdr[4].ToString();
                    byte[] bytes = (byte[])sdr[5];
                    string imgBase64Data = Convert.ToBase64String(bytes);
                    string imgDataURL = string.Format("data:image/jpg;base64,{0}", imgBase64Data);
                    imgContent.ImageUrl = imgDataURL;
                }
                sdr.Close();
            }
        }

        
    }
}