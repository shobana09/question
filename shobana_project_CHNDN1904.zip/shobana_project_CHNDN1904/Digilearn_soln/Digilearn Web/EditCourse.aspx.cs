﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;
using System.Data;
using System.Data.SqlClient;


namespace Digilearn_Web
{
    public partial class EditCourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string uid = (string)Session["USERID"];
            lbUserId.Text = "Welcome " + uid + ", Page Access Time : " + DateTime.Now;
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Digilearn_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            string ccode = txCCode.Text;
            SqlDataReader sdr=CourseManagement.GetCoursesDetailsByCourseCode(ccode);
            if (sdr.Read())
            {
                txCCode.Text = sdr[0].ToString();
                txCDesc.Text = sdr[1].ToString();
                txSkill.Text = sdr[2].ToString();
                txCDate.Text = sdr[3].ToString();
                txCTime.Text = sdr[4].ToString();
                
            }
            sdr.Close();
        }

        protected void bntReset_Click(object sender, EventArgs e)
        {
            txCDate.Text = "";
            txCDesc.Text = "";
            txCTime.Text = "";

            txSkill.Text = "";
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string ccode = txCCode.Text;
                string cdesc = txCDesc.Text;
                string skill = txSkill.Text;
                DateTime CDate = DateTime.Parse(txCDate.Text);
                string CTime = txCTime.Text;
               
                lbStatus.Text = CourseManagement.EditCourseDetails(ccode, cdesc, skill, CDate, CTime);
            }
            catch (Exception ex)
            {
                lbStatus.Text = ex.Message;
            
            }
        }
    }
}