﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;

namespace Digilearn_Web
{
    public partial class UserRegister : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string utype = Request.QueryString["utype"];
            lbWelcome.Text = "Welcome " + utype;
            txUtype.Text = utype.Substring(0, 1);                

        }

        protected void bntReset_Click(object sender, EventArgs e)
        {
            txAge.Text = "";
            txContact.Text = "";
            txDOB.Text = "";
            txEmail.Text = "";
            txtFName.Text = "";
            txtLName.Text = "";
            txPsw.Text = "";
            txUser.Text = "";
            txUtype.Text = "";
            txtFName.Focus();

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                int age = Int32.Parse(txAge.Text);
                string contact = txContact.Text;
                DateTime DOB = DateTime.Parse(txDOB.Text);
                string email = txEmail.Text;
                string FN = txtFName.Text;
                string LN = txtLName.Text;
                string Psw = txPsw.Text;
                string cnfpsw = txcnfpsw.Text;
                string Uid = txUser.Text;
                string utype = txUtype.Text;
                string G="";
                if(rb1.Checked==true)
                {
                  G=rb1.Text;

                }
                if(rb2.Checked==true)
                {
                  G=rb2.Text;
                }
                if (Psw.Equals(cnfpsw))
                {
                    lbStatus.Text = UserTask.GetUserRegistrationStatus(FN, LN, DOB, age, G, contact, Uid, Psw, email, utype);
                }
                else
                {
                    lbStatus.Text = "Confirm Password Not Matched !";
                }
            }

            catch (Exception ex)
            {
                lbStatus.Text = ex.Message;

            }
        }

        protected void txDOB_TextChanged(object sender, EventArgs e)
        {
            DateTime DOB = DateTime.Parse(txDOB.Text);
            int age = (int)(DateTime.Now - DOB).TotalDays / 365;
            txAge.Text = age.ToString();
        }
        
    }
}    