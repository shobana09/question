﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;

namespace Digilearn_Web
{
    public partial class RemoveCourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string uid = (string)Session["USERID"];
            lbUserId.Text = "Welcome " + uid + ", Page Access Time : " + DateTime.Now;
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Digilearn_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {
           lbStatus.Text=CourseManagement.RemoveCourse(txCourseID.Text);
           if (lbStatus.Text == "")
           {
               lbStatus.Text = "Course Details with course code " + txCourseID.Text + " does not exists";
           }

        }
    }
}