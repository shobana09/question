﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;
using System.Data;
using System.Data.SqlClient;

namespace Digilearn_Web
{
    public partial class SearchQuestion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string uid = (string)Session["USERID"];
            lbUserId.Text = "Welcome " + uid + ", Page Access Time : " + DateTime.Now;
            if (!Page.IsPostBack)
            {
                pn1.Visible = false;
            }
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Digilearn_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            int QNO = Int32.Parse(txQNum.Text);
            string ccode = txCCodeNo.Text;
            SqlDataReader sdr=CoursewiseQuestion.GetQuestionDetails(ccode,QNO);
            if (sdr == null)
            {
                lbStatus.Text = "Course code is not valid !";
            }
            if (sdr.Read())
            {
                txCCode.Text = sdr[0].ToString();
                txCQNo.Text = sdr[1].ToString();
                txQText.Text = sdr[2].ToString();
                txAns1.Text = sdr[3].ToString();
                txAns2.Text = sdr[4].ToString();
                txCorrect.Text = sdr[5].ToString();
                
            }
            sdr.Close();
            pn1.Visible = true;
        }
    }
}