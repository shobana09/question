﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;
using System.Data;
using System.Data.SqlClient;

namespace Digilearn_Web
{
    public partial class AttemptQuestion : System.Web.UI.Page
    {
        string[] correctans = null;
        string[] selectedans = null;
        int[] k =null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                pnQ1.Visible = false;
                pnQ2.Visible = false;
                pnQ3.Visible = false;
                pnQ4.Visible = false;
                chkComplete.Visible = false;
                btnSubmit.Visible = false;
            }
            correctans = new string[4];
            selectedans = new string[4];
           k = new int[4];
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            string ccode = txCCodeNo.Text;
            SqlDataReader sdr = CoursewiseQuestion.GetQuestionDetails(ccode);
            if (sdr == null)
            {
                lbStatus.Text = "Course code is not valid !";
            }
            else
            {
                chkComplete.Visible = true;
                int i = 0;
                while (sdr.Read())
                {
                   
                    lbStatus.Text = "Question for - "+sdr[0].ToString();
                    correctans[i] = sdr[5].ToString();
                    k[i] = i + 1;
                    ++i;
                    
                          if (i == 1)
                          {
                              pnQ1.Visible = true;
                              txQNo1.Text = sdr[1].ToString();
                              txQText1.Text = sdr[2].ToString();
                              rb1Q1.Text = sdr[3].ToString();
                              rb2Q1.Text = sdr[4].ToString();
                              
                          }
                          if (i == 2)
                          {
                              pnQ2.Visible = true;
                              txQNo2.Text = sdr[1].ToString();
                              txQText2.Text = sdr[2].ToString();
                              rb1Q2.Text = sdr[3].ToString();
                              rb2Q2.Text = sdr[4].ToString();
                          }
                          if (i == 3)
                          {
                              pnQ3.Visible = true;
                              txQNo3.Text = sdr[1].ToString();
                              txQText3.Text = sdr[2].ToString();
                              rb1Q3.Text = sdr[3].ToString();
                              rb2Q3.Text = sdr[4].ToString();
                          }
                          if (i == 4)
                          {
                              pnQ4.Visible = true;
                              txQNo4.Text = sdr[1].ToString();
                              txQText4.Text = sdr[2].ToString();
                              rb1Q4.Text = sdr[3].ToString();
                              rb2Q4.Text = sdr[4].ToString();
                          }
                          
                }
                sdr.Close();
                Session.Add("CORRECT",correctans);
                Session.Add("Counter", k);
                pn1.Visible = true;
            }
           
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("DigiLearn_Home1.aspx");
            Session.Remove("USERID");
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            int score = 0;
            if (chkComplete.Checked == true)
            {
                selectedans = (string[])Session["SELECTED"];
                correctans = (string[])Session["CORRECT"];

                for (int i = 0; i < 4; i++)
                {
                    if (selectedans[i].Equals(correctans[i]))
                    {
                        ++score; 
                    }
                }
                score = score * 25;
                DateTime completedate = DateTime.Now;
                string userId = (string)Session["USERID"];
                string ccode = txCCodeNo.Text;
                if (CourseManagement.InsertCourseCompletionDetails(userId, ccode, completedate, score) > 0)
                {
                    lbStatus0.Text = "User " + userId + " had successfully completed the course !";
                }
            }
            else
            {
                lbStatus0.Text = "Kindly select I Agree check option !";
            }
            

        }

        protected void chkComplete_CheckedChanged(object sender, EventArgs e)
        {
            if (chkComplete.Checked == true)
            {
                k = (int[])Session["Counter"];
                foreach (int j in k)
                {
                    if (j == 1)
                    {
                        if (rb1Q1.Checked == true)
                        {
                            selectedans[j - 1] = rb1Q1.Text;
                        }
                        if (rb2Q1.Checked == true)
                        {
                            selectedans[j - 1] = rb2Q1.Text;
                        }
                    }
                    if (j == 2)
                    {
                        if (rb1Q2.Checked == true)
                        {
                            selectedans[j - 1] = rb1Q2.Text;
                        }
                        if (rb2Q2.Checked == true)
                        {
                            selectedans[j - 1] = rb2Q2.Text;
                        }
                    }
                    if (j == 3)
                    {
                        if (rb1Q3.Checked == true)
                        {
                            selectedans[j - 1] = rb1Q3.Text;
                        }
                        if (rb2Q3.Checked == true)
                        {
                            selectedans[j - 1] = rb2Q3.Text;
                        }
                    }
                    if (j == 4)
                    {
                        if (rb1Q4.Checked == true)
                        {
                            selectedans[j - 1] = rb1Q4.Text;
                        }
                        if (rb2Q4.Checked == true)
                        {
                            selectedans[j - 1] = rb2Q4.Text;
                        }
                    }

                }
                Session.Add("SELECTED", selectedans);
                btnSubmit.Visible = true;
            }
            else
            {
                btnSubmit.Visible = false;
            }
        }
    }
}