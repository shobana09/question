﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace Digilearn_Web
{
    public partial class UploadQuestion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string uid = (string)Session["USERID"];
            lbUserId.Text = "Welcome " + uid + ", Page Access Time : " + DateTime.Now;
        }

        protected void linkSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Digilearn_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void bntReset_Click(object sender, EventArgs e)
        {
            txCCode.Text = "";
            txCQNo.Text = "";
            txQText.Text = "";
            txAns1.Text = "";
            txAns2.Text = "";
            txCorrect.Text = "";
                txCCode.Focus();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string ccode=txCCode.Text;
            int CQNO=Int32.Parse(txCQNo.Text);
            string QText=txQText.Text;
            string ans1=txAns1.Text;
            string ans2=txAns2.Text;
            string correct=txCorrect.Text;

            int count = CoursewiseQuestion.GetQuestionsCount(ccode);
            if (count > 3)
            {
                lbStatus.Text = "Sorry! You can not upload more than 4 questions related to give course";
            }
            else
            {
                lbStatus.Text = CoursewiseQuestion.InsertQuestion(ccode, CQNO, QText, ans1, ans2, correct);
            
            }
        }
    }
}