﻿using System;
using System.Data;
using System.Data.SqlClient;
using DLTMS_DB;

namespace Business_LIB
{
    public class CourseManagement
    {
        public static SqlDataReader GetAllCoursesSkills()
        {
           return Courses.GetAllCoursesSkills(DBConnector.GetDBConnection());
        }

        public static string EditCourseDetails(string ccode, string cdesc, string skill_set, DateTime CDate, string CTime)
        {
            string message = "";
            try
            {
                
                SqlConnection con = DBConnector.GetDBConnection();
                if (Courses.EditCourseDetails(con, ccode, cdesc, skill_set, CDate, CTime) > 0)
                {
                    message = "Course Details Modified Successfully";
                }
                con.Close();
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }

            return message;
        }

        public static string AddCourseDetails(string ccode, string cdesc, string skill_set, DateTime CDate, string CTime, byte[] other)
        {
            string message="";
            try{
            SqlConnection con = DBConnector.GetDBConnection();
            if (Courses.InsertCourseDetails(con, ccode, cdesc, skill_set, CDate, CTime, other) > 0)
            {
                message = "Course Details Uploaded Successfully";
            }
            con.Close();
            }
            catch(Exception ex)
            {
                message=ex.Message;
            }
            
            return message;
        }

        public static DataSet GetCoursesDetails()
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return Courses.GetAllCoursesDetails(con);
        }

        public static SqlDataReader GetCoursesDetailsByCourseCode(string ccode)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            SqlDataReader sdr = Courses.GetAllCoursesDetails(con, ccode);
            return sdr;
        }

        public static SqlDataReader GetAllCoursesDetails(string ccode, string skill)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return Courses.GetAllCoursesDetails(con,ccode,skill);
        }
        public static string RemoveCourse(string ccode)
        {
            String message="";
            try{
            SqlConnection con = DBConnector.GetDBConnection();
            if(Courses.RemoveCourse(con,ccode)>0)
            {
                message = "Course details with Code No " + ccode + " deleted successfully";
            }
            }catch(Exception ex)
            {
                message=ex.Message;
            }
            return message;
        }


        public static DataSet ViewCourseDetails()
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return Courses.ViewCourseDetails(con);
        }

        public static int InsertCourseCompletionDetails(string userId, string ccode, DateTime completedate, int score)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return Courses.InsertCourseCompletionDetails(con, userId, ccode, completedate, score);
        }

        public static string GetCourseCompleteStatus(string userId, string ccode)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return Courses.GetCourseCompleteStatus(con, userId, ccode);
        }

        public static DataSet ViewCourseCompletionDetails()
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return DLTMS_DB.Courses.ViewCourseCompletionDetails(con);
        }

        public static DataSet ViewCourseCompletionDetails(string ccode)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return DLTMS_DB.Courses.ViewCourseCompletionDetails(con,ccode);
        }
    }
}
