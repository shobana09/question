﻿using System;
using System.Data;
using System.Data.SqlClient;
using DLTMS_DB;

namespace Business_LIB
{
    public class CoursewiseQuestion
    {
        public static SqlDataReader GetQuestionDetails(string ccode)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return DLTMS_DB.CoursewiseQuestion.GetQuestionDetails(con, ccode);
        }
        public static int GetQuestionsCount(string ccode)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            return DLTMS_DB.CoursewiseQuestion.GetQuestionsCount(con, ccode);
        }

        public static string InsertQuestion(string CCode, int CQNo, string QText, string Ans1, string Ans2, string CorrectAnswer)
        {
            String message = "";
            try
            {
                SqlConnection con=DBConnector.GetDBConnection();
                int r=DLTMS_DB.CoursewiseQuestion.InsertQuestion(con,CCode,CQNo,QText,Ans1,Ans2,CorrectAnswer);
                if (r > 0)
                {
                    message = "Question Details Uploaded!";
                }
            }
            catch (Exception ex) { message = ex.Message; }
            return message;
        }

        public static SqlDataReader GetQuestionDetails(string ccode, int QNO)
        {
             SqlConnection con=DBConnector.GetDBConnection();
             return DLTMS_DB.CoursewiseQuestion.GetQuestionDetails(con, ccode, QNO);
        }


        public static string RemoveQuestionDetails(string ccode, int CQNo)
        {
            string message = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                if (DLTMS_DB.CoursewiseQuestion.RemoveQuestionDetails(con, ccode, CQNo) > 0)
                {
                    message = "Question Details Deleted!";
                }
            }
            catch (Exception ex) { message = ex.Message; }
            return message;
        }
    }
}
