﻿using System;
using DLTMS_DB;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Business_LIB
{
    public class UserTask
    {
        public static string VerifyUserLoginStatus(string uid,string psw,string utype)
        {
            string status = "";
            try
            {
                utype = utype.Substring(0, 1);
                SqlConnection con = DBConnector.GetDBConnection();
                 status=DBConnector.validateUserLogin(con, uid, psw, utype);
                 if (status.Equals("Invalid"))
                 {
                     status = "Un-authorized User! Login Credential Mismatched !!";
                 }
            }
            catch (Exception ex)
            {
                status = ex.Message;
            }
            return status;

        }

        public static bool ValidateContactNo(string contact)
        {
            string pattern = "^[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]$";
            Regex rgx = new Regex(pattern);
            if (rgx.IsMatch(contact) == true)
                return true;
            else
                return false;
        }

        public static string GetUserRegistrationStatus(string FN, string LN, DateTime DOB, int age, string G, string contact, string uid, string psw, string email, string utype)
        {
            string message = "";
            try
            {
               SqlConnection con= DBConnector.GetDBConnection();
               if (ValidateContactNo(contact) == true)
               {
                   int r = UserRegister.RegisterUserDetails(con, FN, LN, DOB, age, G, contact, uid, psw, email, utype);
                   if (r > 0)
                   {
                       message = "Registration Succesful!";
                   }
               }
               else
               {
                   message = "Contact No Invalid !!";
               }
            }
            catch(Exception ex)
            {
                message = ex.Message;

            }

            return message;
           
        }

    }
}
